export interface MontadorResultadoInterface{

    adicionarResultado(textoResuldao: string): void;

    

}