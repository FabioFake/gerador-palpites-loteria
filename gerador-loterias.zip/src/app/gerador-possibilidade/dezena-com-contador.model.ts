export class DezenaComContadorModel{

    public dezena: number;
    public vezes: number;

}