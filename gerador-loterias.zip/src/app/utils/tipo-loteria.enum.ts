export enum TipoLoteriaEnum{
    MEGASENA = 6,
    LOTOFACIL = 15
}